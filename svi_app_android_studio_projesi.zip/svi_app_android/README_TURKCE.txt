SVI.APP Android APK projesi

ÖNEMLİ: Bu dosya bir Android Studio proje paketidir; derlenmiş APK dosyası değildir.
Buradaki ortamda Android SDK/Gradle derlemesi çalıştırılmadığı için hazır APK üretilmedi.

APK üretmek için:
1. Bilgisayara Android Studio kur: https://developer.android.com/studio
2. Android Studio'yu aç ve "Open" ile bu klasörü seç.
3. Gradle senkronizasyonunun bitmesini bekle. SDK kurulumu isterse Android SDK 35'i yükle.
4. Üst menüden Build > Build Bundle(s) / APK(s) > Build APK(s) seç.
5. Derleme bitince "locate" bağlantısına bas. APK genellikle app/build/outputs/apk/debug/app-debug.apk yolunda olur.
6. APK'yı Android telefona aktar ve kur. Telefon, bilinmeyen uygulama yükleme izni isteyebilir.

Bu uygulama, svi.app HTML prototipini Android WebView içinde açar. JavaScript ve yerel tarayıcı depolaması açıktır.
Veriler bu cihazdaki uygulama depolamasında kalır. Uygulamayı kaldırmak verileri silebilir.
Çevrim içi senkronizasyon veya hesap sistemi içermez.
